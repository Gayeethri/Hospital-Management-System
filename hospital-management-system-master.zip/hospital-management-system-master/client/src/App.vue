<template>
  <router-view></router-view>
</template>

<script>
export default {
  name: "App",

  data: () => ({
    //
  })
};
</script>
<style>
html {
  overflow-y: scroll;
}
</style>